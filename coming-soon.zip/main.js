
// Szene
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('bg'), alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Herz-Pfad mit Funktion
function heartShape(t) {
  const x = 16 * Math.pow(Math.sin(t), 3);
  const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
  return new THREE.Vector3(x * 0.1, y * 0.1, 0);
}

// Partikel
const particles = [];
const particleCount = 150;
const geometry = new THREE.SphereGeometry(0.05, 6, 6);
const material = new THREE.MeshBasicMaterial({ color: 0xff00cc });

for (let i = 0; i < particleCount; i++) {
  const p = new THREE.Mesh(geometry, material.clone());
  scene.add(p);
  particles.push(p);
}

// Kamera
camera.position.z = 5;

// Animation
let tValues = Array.from({ length: particleCount }, () => Math.random() * Math.PI * 2);
function animate() {
  requestAnimationFrame(animate);
  particles.forEach((p, i) => {
    const t = tValues[i];
    const target = heartShape(t);
    p.position.lerp(target, 0.05);
    tValues[i] += 0.01; // leichtes Schweben
  });
  renderer.render(scene, camera);
}
animate();

// Resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
